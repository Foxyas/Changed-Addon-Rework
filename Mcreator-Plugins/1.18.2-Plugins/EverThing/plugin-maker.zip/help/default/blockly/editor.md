The Blockly editor will decide in which editor this category will be used. 
Only Blockly blocks inside this editor will be able to use it.