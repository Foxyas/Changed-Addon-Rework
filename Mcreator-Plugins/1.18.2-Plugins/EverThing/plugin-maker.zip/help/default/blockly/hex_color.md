This is the color of the category using a hexadecimal color.

To use the same HSV (0 to 360) colors as MCreator you need to set following numbers:
**Saturation** = 37
**Value** = 60

#### Common colors (HSV):
#### Procedures:
- **Block**: 60
- **Command**: 280
- **Dimension**: 123
- **Direction**: 20
- **Entity**: 195
- **GUI**: 110
- **Item**: 350
- **Logic**: 210
- **Math**: 230
- **Player**: 175
- **Text**: 160
- **Projectile**: 300
- **World**: 35

#### AI Tasks
- Basic: 110
- Combat: 200
- Movement: 10
- Other: 250
- Parent owner: 170
- Target: 20
- Villager: 50