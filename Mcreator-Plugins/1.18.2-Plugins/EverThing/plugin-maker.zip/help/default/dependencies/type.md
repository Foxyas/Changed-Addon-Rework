This is the type of one dependency the event provides. Some procedure blocks require specific dependencies to work.
Each generator defines which dependency types they support, inside the `types.yaml` mappings file, but they are all listed below.

Note: Custom variables from external plugins can also be used.

**Dependency types**:
- number
- string
- logic
- blockstate
- itemstack
- direction
- world
- entity
- map
- advancement
- dimensiontype
- actionresulttype
- cmdcontext