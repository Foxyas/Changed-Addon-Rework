This is the Blockly category where the block will be added. This is inside this category the user will need to search to use it.

**Note**: When changing the editor, you will have to click on a category to display the new available categories.