This parameter will inform the user how this event is handled by Minecraft.
When **BOTH** is selected, no special notice is shown.