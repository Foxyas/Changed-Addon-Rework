Check if attribute base value must persist player's death.
Note: Only works with players.