<h3 style="margin-top:0;">Template Weight:<br>( Currently unavailable )</h3>

- <b>Weight (Default: 1):</b> How likely this element is to be chosen when using this template pool.<br>
  - <b>Values between: 1 - 150</b>