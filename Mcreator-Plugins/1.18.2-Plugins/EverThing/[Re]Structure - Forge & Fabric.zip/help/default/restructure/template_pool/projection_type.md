<h3 style="margin-top:0;">Projection Type:</h3>

- <b>Rigid</b>: Similar to the way villager houses are generated into the world. These are fixed structures in the world.

- <b>Terrain matching</b>: Matches the terrain height, similar to how village roads are generated. These will generate with the flow of the surrounding terrain.