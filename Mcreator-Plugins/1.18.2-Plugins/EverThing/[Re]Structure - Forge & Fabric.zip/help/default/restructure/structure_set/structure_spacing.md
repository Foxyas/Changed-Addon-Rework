<h3 style="margin-top:0;">Structure Spacing</h3>

- <b>Min separation</b>: This is the Minimum distance in chunks between two neighboring attempts.

- <b>Max spacing</b>: The Average distance between two neighboring generation attempts.

<hr style="margin-bottom:0;">

<b>Example:</b><br>
<b>Spacing (Max)</b> = <b>5</b>\
<b>Separation (Min)</b> = <b>2</b>

This is when using Random spread.\
(currently set as <b>default</b>)

There will be <b>one</b> structure attempt in each 5 x 5 chunk grid, and only at <b>X</b> can a structure spawn.

=============<br>
=============<br>
==XXX==XXX==X<br>
==XXX==XXX==X<br>
==XXX==XXX==X<br>
=============<br>
=============<br>
==XXX==XXX==X<br>
==XXX==XXX==X<br>
==XXX==XXX==X<br>
=============<br>
=============<br>