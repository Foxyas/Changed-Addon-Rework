<h3 style="margin-top:0;">Random Rotation:</h3>

- Adds random rotation to the structure.
- <b>Default: TRUE</b>