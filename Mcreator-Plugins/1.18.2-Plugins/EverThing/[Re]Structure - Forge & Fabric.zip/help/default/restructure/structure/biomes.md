<h3 style="margin-top:0;">Compatible Biomes:</h3>

- <b>Modded biomes are accepted</b>

- You can specify one or more biomes for your structure to generate in.

 <b>NOTE:</b> If your biome is within a dimension you create; your structure will spawn in that dimension.
