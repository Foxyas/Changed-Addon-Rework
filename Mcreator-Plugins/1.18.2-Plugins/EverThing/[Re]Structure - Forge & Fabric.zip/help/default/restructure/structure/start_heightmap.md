<h3 style="margin-top:0;">Start Heightmap:</h3>

- <b>MOTION BLOCKING</b>: Stores the Y-level of the highest block whose material blocks motion or blocks that contain fluid.

    - Water, Lava or Waterlogging blocks.

- <b>MOTION BLOCKING NO LEAVES</b>: Stores the Y-level of the highest block whose material blocks motion or blocks that contain fluid.

  - Water, Lava or Waterlogging blocks; except various leaves.
  
  - Used <b>Only</b> on server-side.

- <b>OCEAN FLOOR</b>: Stores the Y-level of the highest block whose material blocks motion.

  - Used <b>Only</b> on server-side.

- <b>OCEAN FLOOR WG</b>: Stores the Y-level of the highest block whose material blocks motion or blocks that contain fluid.

  - Water, Lava or Waterlogging blocks.

- <b>WORLD SURFACE</b>: Stores the Y-level of the highest non-air block.

- <b>WORLD SURFACE WG (Default)</b>: Stores the Y-level of the highest non-air block.

  - Used <b>Only</b> during world generation.
  - Automatically deleted after carvers are generated.

- <b>NONE</b>: This will not add a start heightmap, and will be determined by the structure height adjustment.

  - <b>NOTE:</b> If Structure Height adjustment is 0, it will spawn at Y-level 0.